﻿Please make sure you have configured the service as described here:

https://docs.microsoft.com/en-us/dotnet/maui/data-cloud/local-web-services